$.ajaxSetup({
    headers: {  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
});

var SweetAlert = Swal.mixin({
    customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-secondary ms-3'
    },
    buttonsStyling: false
});



$(document).ready(function () {
    $('#all-files-search-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#guest-table-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#archive-files-search-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#suggestion-box-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#category-search-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#file-search-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});

$(document).ready(function () {
    $('#member-search-result').DataTable(
        {
            language: {
              'paginate': {
                'previous': '<span class="prev-icon"><i class="fas fa-angle-double-left"></i></span>',
                'next': '<span class="next-icon"><i class="fas fa-angle-double-right"></i></span>'
              }
            }
          });
});


//CREATE MODALS

$(document).on("click", '#createuser', function(){
    $('#createuserModal').modal('show');
});

$(document).on("click", '#suggest-box', function(){
    $('#createSuggestModal').modal('show');
});

$(document).on("click", '#createmember', function(){
    $('#creatememberModal').modal('show');
});

$(document).on("click", '#createcategory', function(){
    $('#createcategoryModal').modal('show');
});

$(document).on("click", '#createfile', function(){
    $('#createfileModal').modal('show');
});

$(document).on("click", '#uploadprofile', function(){
    $('#uploadprofileModal').modal('show');
});

function viewPhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#profile-picture')
                .attr('src', e.target.result)
                .width(200)
                .height(200);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

//EDIT MODALS

$(document).on("click", "#edit-cat", function(){
    var item = $(this).parents('tr').find('td[category]').attr("category");
    var folderid = $(this).parents('tr').find('td[folderid]').attr("folderid");

    $("#categoryname").val(item); 
    $("#folderid").val(folderid); 

    $('#editcategoryModal').modal('show');    
});

var originalCoauthorsContent;
var viewOriginalCoauthorsContent;

$(document).on("click", "#edit-file", function(){

    var count = $(this).parents('tr').find('td[count]').attr("count");
    var id = $(this).parents('tr').find('td[fileid]').attr("fileid");
    var status = $(this).parents('tr').find('td[status]').attr("status");
    var status_pro = $(this).parents('tr').find('td[status_pro]').attr("status_pro");
    var ordinance_title = $(this).parents('tr').find('td[ordinance_title]').attr("ordinance_title");
    var author = $(this).parents('tr').find('td[author]').attr("author");
    var co_author = $(this).parents('tr').find('td[co_author]').attr("co_author");
    var first = $(this).parents('tr').find('td[first]').attr("first");
    var second = $(this).parents('tr').find('td[second]').attr("second");
    var third = $(this).parents('tr').find('td[third]').attr("third");
    var ordinance_number = $(this).parents('tr').find('td[ordinance_number]').attr("ordinance_number");
    var final_title = $(this).parents('tr').find('td[final_title]').attr("final_title");
    var enactment_date = $(this).parents('tr').find('td[enactment_date]').attr("enactment_date");
    var lce_approval = $(this).parents('tr').find('td[lce_approval]').attr("lce_approval");
    var transmittal = $(this).parents('tr').find('td[transmittal]').attr("transmittal");
    var sp_sl = $(this).parents('tr').find('td[sp_sl]').attr("sp_sl");
    var posted = $(this).parents('tr').find('td[posted]').attr("posted");
    var published = $(this).parents('tr').find('td[published]').attr("published");
    var oldfile = $(this).parents('tr').find('td[oldfile]').attr("oldfile");

    if (!originalCoauthorsContent) {
        originalCoauthorsContent = $('#edit-coauthors-container').html();
    }

     $(`.file-coauthors-${count}`).each(function(index) {
        var value = $(this).val();
        console.log(value);

        var container = document.getElementById("edit-coauthors-container");
        var clone = container.firstElementChild.cloneNode(true);
        container.appendChild(clone);
        $(clone).find(`select[name="co_author[]"]`).val(value);
        container.insertBefore(clone, container.firstChild);
    });

    $("#edit-status").val(status);
    $("#edit-pro-status").val(status_pro);
    $("#edit-ordinance").val(ordinance_title);
    $("#edit-ordinance-number").val(ordinance_number);
    $("#edit-author").val(author);
    $("#edit-coauthor").val(co_author);
    $("#edit-first").val(first);
    $("#edit-second").val(second);
    $("#edit-third").val(third);
    $("#edit-final").val(final_title);
    $("#edit-enactment").val(enactment_date);
    $("#edit-lce").val(lce_approval);
    $("#edit-transmittal").val(transmittal);
    $("#edit-sp").val(sp_sl);
    $("#edit-posted").val(posted);
    $("#edit-published").val(published);
    $("#oldfile").val(oldfile); 
    $("#fileid").val(id); 

    $('#editfileModal').modal('show');  
    
});

$(document).ready(function () {
    $('#editfileModal').on('hidden.bs.modal', function () {
        $('#edit-coauthors-container').empty().html(originalCoauthorsContent);
    });
});


$(document).on("click", "#view-file", function(){
    
    var count = $(this).parents('tr').find('td[count]').attr("count");
    var id = $(this).parents('tr').find('td[fileid]').attr("fileid");
    var status = $(this).parents('tr').find('td[status]').attr("status");
    var status_pro = $(this).parents('tr').find('td[status_pro]').attr("status_pro");
    var ordinance_title = $(this).parents('tr').find('td[ordinance_title]').attr("ordinance_title");
    var author = $(this).parents('tr').find('td[author]').attr("author");
    var co_author = $(this).parents('tr').find('td[co_author]').attr("co_author");
    var first = $(this).parents('tr').find('td[first]').attr("first");
    var second = $(this).parents('tr').find('td[second]').attr("second");
    var third = $(this).parents('tr').find('td[third]').attr("third");
    var ordinance_number = $(this).parents('tr').find('td[ordinance_number]').attr("ordinance_number");
    var final_title = $(this).parents('tr').find('td[final_title]').attr("final_title");
    var enactment_date = $(this).parents('tr').find('td[enactment_date]').attr("enactment_date");
    var lce_approval = $(this).parents('tr').find('td[lce_approval]').attr("lce_approval");
    var transmittal = $(this).parents('tr').find('td[transmittal]').attr("transmittal");
    var sp_sl = $(this).parents('tr').find('td[sp_sl]').attr("sp_sl");
    var posted = $(this).parents('tr').find('td[posted]').attr("posted");
    var published = $(this).parents('tr').find('td[published]').attr("published");
    var status_implementation = $(this).parents('tr').find('td[status_implementation]').attr("status_implementation");
    var oldfile = $(this).parents('tr').find('td[oldfile]').attr("oldfile");
   
    if (!viewOriginalCoauthorsContent) {
        viewOriginalCoauthorsContent = $('#view-coauthors-container').html();
    }

    var list = $('<ul>');

    $(`.file-coauthors-name-${count}`).each(function(index) {
        var value = $(this).val().trim();
        if (value !== '') {
            var listItem = $('<li>').text(value);
            list.append(listItem);
        }
    });

    $('#view-coauthors-container .form-group').append(list);

    $("#view-status").val(status);
    $("#view-pro-status").val(status_pro);
    $("#view-ordinance").val(ordinance_title);
    $("#view-ordinance-number").val(ordinance_number);
    $("#view-author").val(author);
    $("#view-coauthor").val(co_author);
    $("#view-first").val(first);
    $("#view-second").val(second);
    $("#view-third").val(third);
    $("#view-final").val(final_title);
    $("#view-enactment").val(enactment_date);
    $("#view-lce").val(lce_approval);
    $("#view-transmittal").val(transmittal);
    $("#view-sp").val(sp_sl);
    $("#view-posted").val(posted);
    $("#view-published").val(published);

    $('#viewfileModal').modal('show');    
});

$(document).ready(function () {
    $('#viewfileModal').on('hidden.bs.modal', function () {
        $('#view-coauthors-container').empty().html(viewOriginalCoauthorsContent);
    });
});


$(document).on("click", "#edit-account", function(){
    var name = $(this).parents('tr').find('td[name]').attr("name");
    var phone = $(this).parents('tr').find('td[phone]').attr("phone");
    var address = $(this).parents('tr').find('td[address]').attr("address");
    var email = $(this).parents('tr').find('td[email]').attr("email");
    var userid = $(this).parents('tr').find('td[userid]').attr("userid");

    $("#edit-name").val(name); 
    $("#edit-phone").val(phone);
    $("#edit-address").val(address);
    $("#edit-email").val(email);
    $("#userid").val(userid); 

    $('#edituserModal').modal('show');    
});

$(document).on("click", "#edit-mem", function(){
    var name = $(this).parents('tr').find('td[name]').attr("name");
    var birthdate = $(this).parents('tr').find('td[birthdate]').attr("birthdate");
    var address = $(this).parents('tr').find('td[address]').attr("address");
    var civil_status = $(this).parents('tr').find('td[civil_status]').attr("civil_status");
    var position = $(this).parents('tr').find('td[position]').attr("position");
    var gender = $(this).parents('tr').find('td[gender]').attr("gender");
    var status = $(this).parents('tr').find('td[status]').attr("status");
    var from_year = $(this).parents('tr').find('td[from_year]').attr("from_year");
    var to_year = $(this).parents('tr').find('td[to_year]').attr("to_year");
    var photo = $(this).parents('tr').find('td[photo]').attr("photo");
    var memberid = $(this).parents('tr').find('td[memberid]').attr("memberid");
    var email = $(this).parents('tr').find('td[email]').attr("email");

    $("#edit-civil option").filter((i, e) => {
        return e.innerHTML.indexOf(civil_status) > -1;
    }).val();

    $("#edit-position option").filter((i, e) => {
        return e.innerHTML.indexOf(position) > -1;
    }).val();

    $("#edit-gender option").filter((i, e) => {
        return e.innerHTML.indexOf(gender) > -1;
    }).val();

    $("#edit-status option").filter((i, e) => {
        return e.innerHTML.indexOf(status) > -1;
    }).val();

    $("#memberid").val(memberid); 
    $("#edit-name").val(name); 
    $("#edit-birthdate").val(birthdate);
    $("#edit-address").val(address);
    $("#edit-civil").val(civil_status);
    $("#edit-position").val(position);
    $("#edit-gender").val(gender);
    $("#edit-status").val(status);
    $("#edit-from_year").val(from_year);
    $("#edit-to_year").val(to_year);
    $("#edit-photo").val(photo);
    $("#edit-email").val(email);

    $('#editmemberModal').modal('show');    
});

//DELETE SWALS AND DELETE INFO

$(document).on("click", "#delete-cat", function(e){
    var folderid = $(this).parents('tr').find('td[folderid]').attr("folderid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete all files inside this folder.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/removecategory',
                data: {folderid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        window.location.reload();
                    }
                }
            });
        }
    })
});

$(document).on("click", "#delete-file", function(e){
    var fileid = $(this).parents('tr').find('td[fileid]').attr("fileid");

    SweetAlert.fire({
        icon: 'warning',
        title: 'Move to Archive?',
        text: "This will move the file to the archives.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Confirm!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/removefile',
                data: {fileid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Moving...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        window.location.reload();
                    }
                }
            });
        }
    })
});

$(document).on("click", "#delete-account", function(e){
    var userid = $(this).parents('tr').find('td[userid]').attr("userid");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the user permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/removeuser',
                data: {userid},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        window.location.reload();
                    }
                }
            });
        }
    })
});

$(document).on("click", "#delete-mem", function(e){
    var memberid = $(this).parents('tr').find('td[memberid]').attr("memberid");
    var photo = $(this).parents('tr').find('td[photo]').attr("photo");

    SweetAlert.fire({
        icon: 'question',
        title: 'Are you sure?',
        text: "This will delete the SB Member permanently.",
        showCancelButton: true,
        confirmButtonColor: '#160e45',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
    }).then((result) => {
        if (result.value) {
            $.ajax({
                type: 'POST',
                url: '/delete/removemember',
                data: {memberid, photo},
                dataType: 'json',
                cache: false,
                beforeSend:function(){
                    SweetAlert.fire({
                        position: 'center',
                        icon: 'info',
                        title: 'Deleting...',
                        showConfirmButton: false
                    })
                },
                success:function(response){
                    if (response.Error == 0){
                        window.location.reload();
                    }
                }
            });
        }
    })
});

//REGISTER INFORMATION

$(document).on('submit', "#registeruser", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/register/createuser',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-user').show(50);
            $('#processing-user').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-user').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
            if(response.Error == 1) {
                $('#processing-user').hide(50);
                SweetAlert.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    })
});

$(document).on('submit', "#registermember", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/register/createmember',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-member').show(50);
            $('#processing-member').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-member').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
            if(response.Error == 1) {
                $('#processing-member').hide(50);
                SweetAlert.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    })
});

$(document).on('submit', "#registercategory", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/register/createcategory',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-category').show(50);
            $('#processing-category').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-category').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on('submit', "#submit-suggestion", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/createsuggestion',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            SweetAlert.fire({
                position: 'center',
                icon: 'info',
                title: 'Submitting...',
                showConfirmButton: false
            })
        },
        success: function(response)
        {
            if(response.Error == 0) {
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on('submit', "#registerfile", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/register/createfile',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            SweetAlert.fire({
                position: 'center',
                icon: 'info',
                title: 'Processing...',
                showConfirmButton: false
            })
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-file').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on('submit', "#uploadlogo", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/register/uploadlogo',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processing-profile').show(50);
            $('#processing-profile').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processing-profile').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

//EDIT INFORMATION

$(document).on('submit', "#editfile", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/modify/editfile',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processingfile').show(50);
            $('#processingfile').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processingfile').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on('submit', "#editcategory", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/modify/editcategory',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processingcategory').show(50);
            $('#processingcategory').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processingcategory').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
        }
    })
});

$(document).on('submit', "#edituser", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/modify/edituser',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processinguser').show(50);
            $('#processinguser').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processinguser').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
            if(response.Error == 1) {
                $('#processinguser').hide(50);
                SweetAlert.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    })
});

$(document).on('submit', "#editmember", function(e){
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: '/modify/editmember',
        data: new FormData(this),
        dataType: 'json',
        contentType: false,
        cache: false,
        processData:false,
        beforeSend:function(){
            $('#processingmember').show(50);
            $('#processingmember').html('Processing...');
        },
        success: function(response)
        {
            if(response.Error == 0) {
                $('#processingmember').hide(50);
                SweetAlert.fire({
                    icon: 'success',
                    title: 'Done',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                }).then(function(){ 
                    location.reload();
                    });
            }
            if(response.Error == 1) {
                $('#processingmember').hide(50);
                SweetAlert.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: response.Message,
                    confirmButtonColor: "#3a57e8"
                });
            }
        }
    })
});

//SEARCH INFORMATION:
$(document).ready(function(){ 
    $('#user-search').keyup(function(){  
        var user_search = $('#user-search').val();
        
        $.ajax({
            method: 'POST',
            url: '/search/user',
            data: {user_search},
            dataType: 'text',
            success: function(response)
            {
                $('#search-user-result').html(response);
            }
        })
    })
});  

$(document).ready(function(){ 
    $('#member-search').keyup(function(){  
        var member_search = $('#member-search').val();
        
        $.ajax({
            method: 'POST',
            url: '/search/member',
            data: {member_search},
            dataType: 'text',
            success: function(response)
            {
                $('#member-search-result').html(response);
            }
        })
    })
}); 

$(document).ready(function(){ 
    $('#category-search').keyup(function(){  
        var category_search = $('#category-search').val();
        var folderid = $('#folder-id').val();
        
        $.ajax({
            method: 'POST',
            url: '/search/category',
            data: {category_search, folderid},
            dataType: 'text',
            success: function(response)
            {
                $('#category-search-result').html(response);
            }
        })
    })
}); 

$(document).ready(function(){ 
    $('#file-search').keyup(function(){  
        var file_search = $('#file-search').val();
        var folderid = $('#folder-id').val();

        $.ajax({
            method: 'POST',
            url: '/search/file',
            data: {file_search, folderid},
            dataType: 'text',
            success: function(response)
            {
                $('#file-search-result').html(response);
            }
        })
    })
}); 

$(document).ready(function(){ 
    $('#all-files-search').keyup(function(){  
        var all_files_search = $('#all-files-search').val();

        $.ajax({
            method: 'POST',
            url: '/search/allfiles',
            data: {all_files_search},
            dataType: 'text',
            success: function(response)
            {
                $('#all-files-search-result').html(response);
            }
        })
    })
}); 