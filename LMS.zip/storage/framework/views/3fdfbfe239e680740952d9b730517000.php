<table class="table align-items-center mb-0" id="suggestion-box-result">
    <thead>
        <tr>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" width="5%">
                No.
            </th>
            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                Name
            </th>
            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                Suggestion
            </th>
        </tr>
    </thead>
    <tbody>
    <?php $cnt = 1; ?>
        <?php $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
           <td class="text-center text-xs"><?php echo e($cnt); ?></td>
           <td class="text-wrap text-sm text-center"><?php echo e($sug->name); ?></td>
           <td class="text-wrap text-xs text-center"><?php echo e($sug->suggestions); ?></td>
        </tr>
        <?php $cnt += 1; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\LMS\resources\views/table/suggestion-table.blade.php ENDPATH**/ ?>