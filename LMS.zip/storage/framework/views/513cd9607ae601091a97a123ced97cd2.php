<table class="table align-items-center mb-0" id="member-search-result">
    <thead>
    <tr>
        <th class="text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7" width="5%">No.</th>
        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Address</th>
        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Term</th>
        <?php if(Auth::user()->type == 1): ?>  
        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Action</th>
        <?php endif; ?>
    </tr>
    </thead>
    <tbody>
        <?php
            $count = 1;
        ?>
    <?php $__currentLoopData = $sbmembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center">
            <?php echo e($count); ?>

        </td>
        <td
        
         memberid='<?php echo e($mem->id); ?>'
         name='<?php echo e($mem->name); ?>'
         birthdate='<?php echo e($mem->birthdate); ?>'
         address='<?php echo e($mem->address); ?>'
         civil_status='<?php echo e($mem->civil_status); ?>'
         position='<?php echo e($mem->position); ?>'
         gender='<?php echo e($mem->gender); ?>'
         status='<?php echo e($mem->status); ?>'
         from_year='<?php echo e($mem->from_year); ?>'
         to_year='<?php echo e($mem->to_year); ?>'
         photo='<?php echo e($mem->photo); ?>'
         email='<?php echo e($mem->User->email); ?>'
            
        >
        <div class="d-flex px-2 py-1">
            <div>
            <img src="<?php echo e(asset('/storage/photo/'.$mem->photo)); ?>" class="avatar avatar-sm me-3" alt="user1">
            </div>
            <div class="d-flex flex-column justify-content-center">
            <h6 class="mb-0 text-sm"><?php echo e($mem->name); ?></h6>

            <?php if($mem->position == 1): ?>
                <p class="text-xs text-secondary mb-0">Mayor</p>
            <?php endif; ?>
            <?php if($mem->position == 2): ?>
                <p class="text-xs text-secondary mb-0">Vice Mayor</p>
            <?php endif; ?>
            <?php if($mem->position == 3): ?>
                <p class="text-xs text-secondary mb-0">Municipal Councilor</p>
            <?php endif; ?>
           
            </div>
        </div>
        </td>
        <td>
        <p class="text-xs font-weight-bold mb-0"><?php echo e($mem->address); ?></p>
        </td>
        <td class="align-middle text-center text-sm">
        <?php if($mem->status == 1): ?>
            <span class="badge badge-sm bg-gradient-success">Active</span>
        <?php endif; ?>
        <?php if($mem->status == 0): ?>
            <span class="badge badge-sm bg-gradient-danger">Inactive</span>
        <?php endif; ?>
        </td>
        <td class="align-middle text-center">
        <span class="text-secondary text-xs font-weight-bold"><?php echo e(date('M d, Y', strtotime($mem->from_year))); ?> - <?php echo e(date('M d, Y', strtotime($mem->to_year))); ?></span>
        </td>
        <?php if(Auth::user()->type == 1): ?>  
        <td class="text-center">
        <a href="#" id="edit-mem" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Edit">
            <i class="fas fa-user-edit text-secondary"></i>
        </a>
        <!--
        <a href="#" id="delete-mem" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Delete">
            <i class="cursor-pointer fas fa-trash text-secondary"></i>
        </a> -->
        </td>
        <?php
            $count += 1;
        ?>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/pmsnetph/public_html/legislative-ms/resources/views/table/member-table.blade.php ENDPATH**/ ?>